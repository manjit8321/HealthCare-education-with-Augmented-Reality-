import 'package:flutter/material.dart';
const kCardColor = Color(0xFF50C6D0);
const kLightCardColor = Color(0xFFDBF8FF);
const kShadowColor = Color(0xFFF7F7F7);
const kTextColor = Color(0XFF737373);
const kSearchBoxColor = Color(0xFFF9F9FC);