import 'package:flutter/material.dart';

class OrganItem with ChangeNotifier{
  OrganItem({
    this.id,
    this.name,
    this.category,
});
  final String id;
  final String name;
  final String category;
}

class Organs with ChangeNotifier{
  List<OrganItem> _allOrgans =[
    OrganItem(
      id: "armModel",
      name: "Arm Skeleton",
      category: "Skeletal"
    ),
    OrganItem(
      id: "brainModel",
      name: "Brain",
      category: "Nervous"
    ),
    OrganItem(
      id: "footModel",
      name: "Foot Skeleton",
      category: "Skeletal"
    ),
    OrganItem(
      id: "heartModel",
      name: "Heart",
      category: "Circulatory"
    ),
    OrganItem(
      id: "teethModel",
      name: "Teeth",
      category: "Skeletal"
    ),
    OrganItem(
      id: "legModel",
      name: "Leg Bone",
      category: "Skeletal"
    ),
    OrganItem(
      id: "eyeModel",
      name: "Eye Ball",
      category: "Integumentary"
    ),
    OrganItem(
      id: "skeletonModel",
      name: "Skeleton",
      category: "Skeletal"
    ),
    OrganItem(
      id: "skullModel",
      name: "skull",
      category: "Skeletal"
    ),
    OrganItem(
      id: "thoraxModel",
      name: "Thorax",
      category: "Skeletal"
    ),
    OrganItem(
      id: "toothModel",
      name: "Tooth",
      category: "Skeletal",
    ),
  ];

  List<OrganItem> get organs {
    return [...organs];
  }

  List<OrganItem> getOrgansByCat(String category){
    return _allOrgans.where((element) => element.category == category).toList();
  }

  List<OrganItem> getOrgans(String organ){
    return _allOrgans.where((element) => element.name.contains(RegExp(organ, caseSensitive: false ))).toList();
  }
}